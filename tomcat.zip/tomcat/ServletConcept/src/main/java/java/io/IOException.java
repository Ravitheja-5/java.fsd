package java.io;

public class IOException {

}
