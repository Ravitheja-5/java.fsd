package com.practice;
import java.sql.*;
public class Jdbc1 {
public static void main(String arg[]) throws Exception {
	
		Class.forName("com.mysql.jdbc.Driver");//load and register
		Connection com=DriverManager.getConnection("jdbc:mysql://localhost:3306/mphasis_db","root","suvashree#1234");
		PreparedStatement ps=com.prepareStatement("select * from product");
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			String name1=rs.getString("pid");
			System.out.println(name1);
			
		}
	}
}
