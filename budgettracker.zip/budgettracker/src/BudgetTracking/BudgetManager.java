package BudgetTracking;
import java.util.Scanner;
import java.util.HashMap;
import java.util.Map;

public class BudgetManager {
    private static String username;
    private static String password;
    private static double monthlyBudget = 0;
    private static Map<String, Double> budgetaryLogs = new HashMap<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Task 1: Log in");
            System.out.println("Task 2: Set a monthly budget");
            System.out.println("Task 3: Record an expense");
            System.out.println("Task 4: Budgetary logs");
            System.out.println("Task 5: Date-wise logs");
            System.out.println("Task 6: Month-wise log");
            System.out.println("Task 7: Total budget");
            System.out.println("Task 8: Delete budgetary logs");
            System.out.println("Task 9: Change the password");
            System.out.println("Task 10: Exit");
            System.out.print("Select a task (1-10): ");

            int task = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (task) {
                case 1:
                    login(scanner);
                    break;
                case 2:
                    setMonthlyBudget(scanner);
                    break;
                case 3:
                    recordExpense(scanner);
                    break;
                case 4:
                    displayBudgetaryLogs();
                    break;
                case 5:
                    displayDateWiseLogs(scanner);
                    break;
                case 6:
                    displayMonthWiseLog(scanner);
                    break;
                case 7:
                    displayTotalBudget();
                    break;
                case 8:
                    deleteBudgetaryLogs(scanner);
                    break;
                case 9:
                    changePassword(scanner);
                    break;
                case 10:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid task. Please try again.");
                    break;
            }
        }
    }

    private static void login(Scanner scanner) {
        System.out.print("Enter username: ");
        username = scanner.nextLine();
        System.out.print("Enter password: ");
        password = scanner.nextLine();
        System.out.println("Logged in successfully.");
    }

    private static void setMonthlyBudget(Scanner scanner) {
        if (username == null || password == null) {
            System.out.println("Please log in first.");
            return;
        }

        System.out.print("Enter monthly budget: ");
        monthlyBudget = scanner.nextDouble();
        scanner.nextLine(); // Consume the newline character
        System.out.println("Monthly budget set to $" + monthlyBudget);
    }

    private static void recordExpense(Scanner scanner) {
        if (username == null || password == null) {
            System.out.println("Please log in first.");
            return;
        }

        if (monthlyBudget == 0) {
            System.out.println("Please set a monthly budget first.");
            return;
        }

        System.out.print("Enter the expense description: ");
        String description = scanner.nextLine();
        System.out.print("Enter the expense amount: ");
        double expenseAmount = scanner.nextDouble();
        scanner.nextLine(); // Consume the newline character

        if (budgetaryLogs.containsKey(description)) {
            double existingExpense = budgetaryLogs.get(description);
            budgetaryLogs.put(description, existingExpense + expenseAmount);
        } else {
            budgetaryLogs.put(description, expenseAmount);
        }

        System.out.println("Expense recorded: " + description + " $" + expenseAmount);
    }

    private static void displayBudgetaryLogs() {
        if (username == null || password == null) {
            System.out.println("Please log in first.");
            return;
        }

        System.out.println("Budgetary Logs:");
        for (Map.Entry<String, Double> entry : budgetaryLogs.entrySet()) {
            System.out.println(entry.getKey() + ": $" + entry.getValue());
        }
    }

    private static void displayDateWiseLogs(Scanner scanner) {
        // Implement this task if needed
    }

    private static void displayMonthWiseLog(Scanner scanner) {
        // Implement this task if needed
    }

    private static void displayTotalBudget() {
        if (username == null || password == null) {
            System.out.println("Please log in first.");
            return;
        }

        System.out.println("Total Budget: $" + monthlyBudget);
    }

    private static void deleteBudgetaryLogs(Scanner scanner) {
        if (username == null || password == null) {
            System.out.println("Please log in first.");
            return;
        }

        budgetaryLogs.clear();
        System.out.println("Budgetary logs deleted.");
    }

    private static void changePassword(Scanner scanner) {
        if (username == null || password == null) {
            System.out.println("Please log in first.");
            return;
        }

        System.out.print("Enter the new password: ");
        password = scanner.nextLine();
        System.out.println("Password changed successfully.");
    }
}