package demosync;
 class synchro
 { 
     public void send(String msg) 
     { 
         System.out.println("Sending\t"  + msg ); 
         try
         { 
             Thread.sleep(1000); 
         } 
         catch (Exception e) 
         { 
             System.out.println("Thread  interrupted."); 
         } 
         System.out.println("\n" + msg + "Sent"); 
     } 
 } 
 class ThreadedSend extends Thread 
 { 
     private String msg; 
     private Thread t; 
     synchro  synchro; 
     ThreadedSend(String m,  synchro obj) 
     { 
         msg = m; 
         synchro = obj; 
     } 
   
     public void run() 
     {  
         synchronized(synchro) 
         { 
             synchro.send(msg); 
         } 
     } 
 } 
 class Synchro 
 { 
     public static void main(String args[]) 
     { 
         synchro snd = new synchro(); 
         ThreadedSend S1 = 
             new ThreadedSend( " Hi guys " , snd ); 
         ThreadedSend S2 = 
             new ThreadedSend( " Hello guys " , snd ); 
         S1.start(); 
         S2.start(); 
         try
         { 
             S1.join(); 
             S2.join(); 
         } 
         catch(Exception e) 
         { 
             System.out.println("Interrupted"); 
         } 
     } 
 }