package threadsdemo;

	class MyThread extends Thread {
		
	    @Override
	    public void run() {
	        for (int i = 1; i <= 5; i++) {
	            System.out.println("Thread (extending Thread class): " + i);
	        }
	    }
	}

	class MyRunnable implements Runnable {
	    @Override
	    public void run() {
	        for (int i = 1; i <= 5; i++) {
	            System.out.println("Thread (implementing Runnable interface): " + i);
	        }
	    }
	}

	public class ThreadExample {
	    public static void main(String[] args) {
	        MyThread thread1 = new MyThread();
	        MyRunnable runnable = new MyRunnable();
	        Thread thread2 = new Thread(runnable);
	        thread1.start();
	        thread2.start();
	    }
	}




