package exceptionhandling;

public class Except {
	class MyException extends Exception {
	    String str1;

	    MyException(String str2) {
	        str1 = str2;
	    }

	    @Override
	    public String toString() {
	        return "MyException Occurred: " + str1;
	    }
	}

	public class Except {
	    public static void main(String[] args) {
	        try {
	            System.out.println("Starting of try block");
	            // Throw the custom exception using throw
	            throw new MyException("This is My error Message");
	        } catch (MyException exp) {
	            System.out.println("Catch Block");
	            System.out.println(exp);
	        }
	    }
	}
}
